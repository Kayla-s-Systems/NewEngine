# NewEngine Profiler Report

- reason: `service.shutdown_v1`
- uptime_ms: `118.864`
- events_seen: `233`
- malformed_events: `0`

## Summary

| Metric | Value |
|---|---:|
| `active_jobs` | `0.000` |
| `completed_jobs_kept` | `233.000` |
| `failed_jobs` | `0.000` |
| `slow_or_over_budget_jobs` | `0.000` |
| `total_elapsed_ms` | `0.000` |
| `average_elapsed_ms` | `0.000` |
| `max_elapsed_ms` | `0.000` |

## By category

| Category | Count | Failed | Slow | Total ms | Max ms |
|---|---:|---:|---:|---:|---:|
| `event` | 233 | 0 | 0 | 0.000 | 0.000 |

## Recent completed jobs

| Status | Category | Name | Elapsed ms | Load | Detail |
|---|---|---|---:|---:|---|
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.loading.status.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.loading.status.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.loading.status.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.loading.status.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.loading.status.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.loading.status.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.loading.status.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.task.event.v1` | 0.000 | 0.00 | event observed |
| `completed` | `event` | `engine.jobs.event.v1` | 0.000 | 0.00 | event observed |

## Diagnostics

No diagnostics recorded.
